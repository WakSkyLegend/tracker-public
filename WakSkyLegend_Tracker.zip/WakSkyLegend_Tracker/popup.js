import { visiblePlatforms, visibleContent, visibleScheduled, scheduledLabel, audienceSummary, audienceNumber, audienceCompact } from "./lib/core.js";
import { CREATOR, TAGLINE, DISCORD_URL } from "./config.js";
import { broadcastRelativeLabel, broadcastEndLabel } from "./lib/broadcasts.js";
import { createCommunityView } from "./lib/community-view.js";
import { CREATOR_BUILD } from "./build.js";
const $ = id => document.getElementById(id);
let data, busy = false;
let communityDraft = null;
const renderCommunity = createCommunityView(document);
if (CREATOR_BUILD && globalThis.top !== globalThis) window.addEventListener("message", event => {
  if (event.source !== parent || event.origin !== location.origin || event.data?.scope !== "wak-creator-draft") return;
  communityDraft = event.data.config; if (data) render();
});
const signatures = new Map();
function logo(path) { const image = document.createElement("img"); image.src = chrome.runtime.getURL(path); image.alt = ""; image.width = 18; image.height = 18; return image; }
function formatDate(value, compact = false) { return value ? new Date(value).toLocaleString("fr-FR", { ...(compact ? {} : { weekday: "long" }), day: "numeric", month: compact ? "short" : "long", year: "numeric", ...(compact ? {} : { hour: "2-digit", minute: "2-digit" }) }) : "Date non communiquée par la plateforme"; }
function thumbnail(url, label, className, portrait = false) {
  const cover = document.createElement("span"); cover.className = className;
  const fallback = document.createElement("span"); fallback.className = "thumbnail-fallback"; fallback.textContent = "Miniature indisponible"; fallback.hidden = Boolean(url);
  if (url) {
    const image = document.createElement("img"); image.src = url; image.alt = label; image.width = portrait ? 108 : 320; image.height = portrait ? 192 : 180; image.referrerPolicy = "no-referrer"; image.loading = "lazy";
    let retried = false;
    image.addEventListener("error", () => {
      if (!retried) {
        retried = true;
        try { const alternative = new URL(url); if (/^i[1-4]?\.ytimg\.com$/.test(alternative.hostname)) { alternative.hostname = alternative.hostname === "i.ytimg.com" ? "i1.ytimg.com" : "i.ytimg.com"; image.src = alternative.href; return; } } catch { /* No remote fallback for local demo assets. */ }
      }
      image.hidden = true; fallback.hidden = false;
    });
    cover.append(image);
  }
  cover.append(fallback); return cover;
}
function link(url, className) { const a = document.createElement("a"); a.href = url; a.className = className; a.target = "_blank"; a.rel = "noopener noreferrer"; return a; }
function liveLink(item, className) {
  const a = link(item.url, className);
  a.setAttribute("data-live-platform", item.id);
  a.addEventListener("click", async event => {
    // The installed extension resolves the latest detected session. Read-only
    // web previews retain the native validated href and standard modified clicks.
    if (!chrome.runtime.id || event.button > 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
    event.preventDefault();
    if (a.getAttribute("aria-busy") === "true") return;
    a.setAttribute("aria-busy", "true");
    try {
      const result = await chrome.runtime.sendMessage({ type: "OPEN_LIVE", platform: item.id });
      if (!result?.ok) throw new Error(result?.error || "Le direct ne peut pas être ouvert pour le moment.");
      data = result; render();
    } catch (error) { $("notice").textContent = error.message; $("notice").hidden = false; }
    finally { a.removeAttribute("aria-busy"); }
  });
  return a;
}
function staleNote(entry) { if (!entry.stale) return null; const note = document.createElement("small"); note.className = "content-status"; note.textContent = "Dernier contenu vérifié le " + formatDate(entry.checkedAt) + ". Nouvelle lecture en cours."; return note; }
function publicationCard(video, entry) {
  const card = link(entry.item?.url ?? (video ? "https://www.youtube.com/@wakskylegend/videos" : "https://x.com/wakskylegend"), "publication " + (video ? "video-publication" : "post-publication"));
  const body = document.createElement("span"); body.className = "publication-copy";
  if (entry.status === "ready") {
    if (video || entry.item.thumbnailUrl) card.append(thumbnail(entry.item.thumbnailUrl, video ? "Miniature : " + entry.item.title : "Image du post X", "video-cover" + (video ? "" : " post-cover")));
    const title = document.createElement(video ? "strong" : "span"); title.className = video ? "publication-title" : "post-text"; title.textContent = video ? entry.item.title : entry.item.text;
    const meta = document.createElement("span"); meta.className = "publication-meta";
    const date = document.createElement("time"); if (entry.item.publishedAt) date.dateTime = entry.item.publishedAt; date.textContent = "Publié le " + formatDate(entry.item.publishedAt);
    const action = document.createElement("span"); action.textContent = video ? "Regarder ↗" : "Lire sur X ↗";
    meta.append(date, action); body.append(title, meta); const stale = staleNote(entry); if (stale) body.append(stale);
  } else {
    const message = document.createElement("span"); message.className = "publication-empty";
    message.textContent = entry.status === "empty" ? "Aucune publication publique." : (/failed to fetch|fetch failed/i.test(entry.reason ?? "") ? "Lecture de la source momentanément indisponible." : entry.reason) || "Lecture des publications en cours…";
    const action = document.createElement("small"); action.className = "publication-meta"; action.textContent = video ? "Ouvrir les vidéos ↗" : "Ouvrir le profil X ↗";
    body.append(message, action);
  }
  card.append(body); return card;
}
function renderPublication(kind, entry) {
  const video = kind === "latestVideo", holder = $(video ? "latest-video" : "latest-post");
  const items = !video && entry.status === "ready" && entry.items?.length ? entry.items.slice(0, 2) : [entry.item];
  holder.replaceChildren(...items.map(item => publicationCard(video, { ...entry, item })));
}
function renderVerticals(entry) {
  const holder = $("vertical-videos"); holder.replaceChildren();
  if (entry.status !== "ready") { const message = link("https://www.youtube.com/@wakskylegend/shorts", "vertical-empty"); message.textContent = entry.status === "empty" ? "Aucun Short public. Ouvrir la chaîne ↗" : (/failed to fetch|fetch failed/i.test(entry.reason ?? "") ? "Lecture des Shorts momentanément indisponible. Ouvrir la chaîne ↗" : entry.reason) || "Lecture des Shorts en cours…"; holder.append(message); return; }
  for (const item of entry.items) {
    const card = link(item.url, "vertical-card"); card.setAttribute("aria-label", "Regarder : " + item.title);
    const cover = thumbnail(item.thumbnailUrl, "Miniature : " + item.title, "vertical-cover", true);
    const play = document.createElement("span"); play.className = "vertical-play"; play.textContent = "▶"; play.setAttribute("aria-hidden", "true"); cover.append(play);
    const title = document.createElement("strong"); title.textContent = item.title;
    const date = document.createElement("time"); if (item.publishedAt) date.dateTime = item.publishedAt; date.textContent = formatDate(item.publishedAt, true);
    card.append(cover, title, date); holder.append(card);
  }
  const stale = staleNote(entry); if (stale) holder.append(stale);
}
function changed(key, value) { const signature = JSON.stringify(value); if (signatures.get(key) === signature) return false; signatures.set(key, signature); return true; }
function renderLastBroadcast(entry) {
  const holder = $("latest-broadcast");
  holder.hidden = entry.status !== "ready";
  if (holder.hidden) return;
  const item = entry.item, card = link(item.url, "broadcast-archive");
  card.append(thumbnail(item.thumbnailUrl, "Miniature du dernier direct : " + item.title, "broadcast-cover"));
  const copy = document.createElement("span"); copy.className = "broadcast-archive-copy";
  const heading = document.createElement("strong"); heading.textContent = broadcastRelativeLabel(item);
  const platform = document.createElement("small"); platform.textContent = "YouTube · " + item.title;
  const end = document.createElement("time"); if (item.endedAt) end.dateTime = item.endedAt; end.textContent = broadcastEndLabel(item);
  copy.append(heading, platform, end);
  const note = staleNote(entry); if (note) copy.append(note);
  card.append(copy); holder.replaceChildren(card);
}
function renderAudience(cache) {
  const summary = audienceSummary(cache);
  $("audience-total").textContent = "≈ " + audienceCompact(summary.rounded);
  $("audience-total").setAttribute("aria-label", "Environ " + audienceNumber(summary.rounded) + " abonnés cumulés sur YouTube, Twitch, TikTok et Kick");
  if (!changed("audience", summary.platforms.map(item => ({ ...item, checkedAt: item.checkedAt.slice(0, 16) })))) return;
  const rows = summary.platforms.map(item => {
    const row = document.createElement("li"), label = document.createElement("span"), value = document.createElement("strong");
    label.textContent = item.name; value.textContent = (item.precision > 1 ? "≈ " : "") + audienceNumber(item.value);
    row.title = "Relevé public du " + formatDate(item.checkedAt) + (item.stale ? " · nouvelle vérification en cours" : "");
    row.append(label, value); return row;
  });
  $("audience-platforms").replaceChildren(...rows);
  const oldest = Math.min(...summary.platforms.map(item => Date.parse(item.checkedAt)));
  $("audience-date").textContent = "Relevés publics depuis le " + new Date(oldest).toLocaleDateString("fr-FR") + ". Actualisation automatique toutes les 6 h.";
}

function render() {
  if (!data) return;
  const { settings, state } = data;
  renderCommunity(communityDraft ?? state.community);
  renderAudience(state.audience);
  $("tagline").textContent = TAGLINE; $("discord").href = (communityDraft??state.community)?.links?.discordUrl || DISCORD_URL;
  const items = visiblePlatforms(state, settings), live = items.filter(item => item.status === "live"), unknown = items.filter(item => item.status === "unknown"), scheduled = visibleScheduled(state, settings);
  const content = visibleContent(state, settings), lastBroadcast = content.latestBroadcast.item;
  const lastBroadcastAt = Date.parse(lastBroadcast?.endedAt ?? lastBroadcast?.startedAt ?? lastBroadcast?.publishedAt);
  const offlineSummary = !live.length && !unknown.length && !scheduled.length && Number.isFinite(lastBroadcastAt) && lastBroadcastAt <= Date.now()
    ? broadcastRelativeLabel(lastBroadcast).replace(/^Dernier direct /, "Dernière diffusion ") : "";
  const pending = unknown.length === items.length && !items.some(item => item.checkedAt);
  $("global-status").textContent = live.length ? "En direct" : scheduled.length ? scheduled.some(item => item.kind !== "video") ? "Live programmé" : "Vidéo programmée" : pending ? "Vérification…" : unknown.length === items.length ? "Détection indisponible" : unknown.length ? "Aucun direct détecté" : "Hors ligne";
  $("signal").classList.toggle("is-live", live.length > 0);
  $("live-highlight").classList.toggle("is-live", live.length > 0);
  const nextScheduled = !live.length && (scheduled.find(item => item.kind !== "video") ?? scheduled[0]);
  $("signal").classList.toggle("is-scheduled", Boolean(nextScheduled));
  $("live-highlight").classList.toggle("is-scheduled", Boolean(nextScheduled));
  $("scheduled-at").hidden = !nextScheduled;
  $("scheduled-at").textContent = nextScheduled ? scheduledLabel(nextScheduled) : "";
  if (nextScheduled?.scheduledStartAt) $("scheduled-at").dateTime = nextScheduled.scheduledStartAt;
  else $("scheduled-at").removeAttribute("datetime");
  $("summary").textContent = !live.length && unknown.length && !pending ? unknown.map(item => item.name).join(", ") + " : statut momentanément indisponible." : offlineSummary;
  $("summary").hidden = !$("summary").textContent;
  $("live-platforms").hidden = live.length === 0;
  if (changed("live-buttons", live.map(item => ({ id: item.id, url: item.url })))) {
    $("live-platforms").replaceChildren();
    for (const item of live) { const button = liveLink(item, "live-logo-link"); button.setAttribute("aria-label", "Regarder le direct détecté de WakSkyLegend sur " + item.name); button.append(logo(item.logo), document.createTextNode(item.name)); $("live-platforms").append(button); }
  }
  $("live-covers").hidden = live.length === 0;
  if (changed("live-covers", live.map(item => ({ id: item.id, url: item.url, title: item.title, thumbnailUrl: item.thumbnailUrl })))) {
    $("live-covers").replaceChildren();
    for (const item of live) { const card = liveLink(item, "broadcast-card"); card.setAttribute("aria-label", "Direct " + item.name + " : " + (item.title || CREATOR)); card.append(thumbnail(item.thumbnailUrl, "Miniature du direct " + item.name, "broadcast-cover")); if (item.title) { const title = document.createElement("strong"); title.textContent = item.title; card.append(title); } $("live-covers").append(card); }
  }
  $("scheduled-lives").hidden = scheduled.length === 0;
  if (changed("scheduled", scheduled.map(item => ({ ...item, checkedAt: undefined, waiting: Date.parse(item.scheduledStartAt) <= Date.now() })))) {
    $("scheduled-lives").replaceChildren();
    for (const event of scheduled) { const card = link(event.url, "scheduled-card"); const title = document.createElement("strong"); title.textContent = (event.kind === "video" ? "Vidéo programmée · " : "Live programmé · ") + (event.title || "YouTube"); const date = document.createElement("time"); if (event.scheduledStartAt) date.dateTime = event.scheduledStartAt; date.textContent = scheduledLabel(event); card.append(thumbnail(event.thumbnailUrl, "Miniature de la publication programmée", "broadcast-cover"), title, date); $("scheduled-lives").append(card); }
  }
  const notice = [state.communityError,state.feedError,state.notificationError,state.collectorError].filter(Boolean).join(" ");
  $("notice").textContent = notice; $("notice").hidden = !notice;
  const lastRead = state.lastSourceCheckAt || state.lastSuccessAt;
  $("updated").textContent = lastRead ? "Mis à jour à " + new Date(lastRead).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit", second: "2-digit" }) : "Lecture des sources…";
  $("auto-refresh").textContent = "Suivi · 5 s · Studio r"+(state.community?.revision??0); $("auto-refresh").title=state.communityCheckedAt?"Studio vérifié à "+new Date(state.communityCheckedAt).toLocaleTimeString("fr-FR"):"Connexion au Studio en attente";
  if (changed("latestBroadcast", { ...content.latestBroadcast, checkedAt: content.latestBroadcast.stale ? content.latestBroadcast.checkedAt : undefined, relative: broadcastRelativeLabel(content.latestBroadcast.item) })) renderLastBroadcast(content.latestBroadcast);
  for (const kind of ["latestVideo", "verticalVideos", "latestPost"]) { const entry = content[kind]; if (!changed(kind, { ...entry, checkedAt: entry.stale ? entry.checkedAt : undefined })) continue; if (kind === "verticalVideos") renderVerticals(entry); else renderPublication(kind, entry); }
}
async function rpc(type) { const result = await chrome.runtime.sendMessage({ type }); if (!result?.ok) throw new Error(result?.error || "La lecture de l’extension est momentanément indisponible."); return result; }
async function refresh(type = "GET_STATE") { if (busy) return; busy = true; try { data = await rpc(type); render(); } catch (error) { $("notice").textContent = error.message; $("notice").hidden = false; } finally { busy = false; } }
if (globalThis.top && globalThis.top !== globalThis) $("full-view").hidden = true;
$("full-view").addEventListener("click", () => chrome.tabs.create({ url: chrome.runtime.getURL("demo.html") }));
chrome.storage.onChanged.addListener((changes, area) => { if (area !== "local" || !data) return; if (changes.settings) data.settings = changes.settings.newValue; if (changes.state) data.state = changes.state.newValue; render(); });
renderAudience();
void refresh("CHECK_PANEL");
setInterval(() => { if (!document.hidden) void refresh("CHECK_PANEL"); }, 5_000);
document.addEventListener("visibilitychange", () => { if (!document.hidden) void refresh("CHECK_PANEL"); });
