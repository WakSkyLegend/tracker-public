// Adresses du site public des spectateurs (GitHub Pages), alimenté par le Studio.
// Aucun secret, mot de passe ou jeton API ne doit être placé dans l’extension.
export const PUBLIC_STATUS_URL = "https://wakskylegend.github.io/tracker-public/tracker.json";
export const COMMUNITY_URL = "https://wakskylegend.github.io/tracker-public/community.json";
export const YOUTUBE_CHANNEL_ID = "UCv1g7SfFGovfac7ATlpBEJg";
export const CREATOR = "WakSkyLegend";
export const APP_NAME = "WakSkyLegend - Tracker";
export const TAGLINE = "Reste informé des lives et des publications de WakSkyLegend.";
export const DISCORD_URL = "https://discord.gg/TDNPVcqmyE";
export const PLATFORMS = Object.freeze([
  { id: "youtube", name: "YouTube", logo: "logos/youtube.svg", color: "#ff4c4c", url: "https://www.youtube.com/@wakskylegend/live" },
  { id: "twitch", name: "Twitch", logo: "logos/twitch.svg", color: "#b794ff", url: "https://www.twitch.tv/wakskylegend" },
  { id: "tiktok", name: "TikTok", logo: "logos/tiktok.svg", color: "#6ce8e5", url: "https://www.tiktok.com/@wakskylegend/live" },
  { id: "kick", name: "Kick", logo: "logos/kick.svg", color: "#83ed56", url: "https://kick.com/wakskylegend" }
]);
