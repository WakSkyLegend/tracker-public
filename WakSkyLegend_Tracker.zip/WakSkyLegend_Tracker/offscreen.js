import { installOffscreenCollector } from "./lib/offscreen-controller.js";
installOffscreenCollector();
