import {installAutomaticUpdates} from "./lib/automatic-updates.js";
import { installBackground } from "./lib/background-controller.js";
import { CREATOR_BUILD } from "./build.js";
const tracker=installBackground({ creator: CREATOR_BUILD });
installAutomaticUpdates({prepare:()=>tracker.prepareUpdate(),resume:()=>tracker.resumeAfterUpdateFailure()});
