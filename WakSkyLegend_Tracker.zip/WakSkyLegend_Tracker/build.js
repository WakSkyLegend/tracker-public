// The public distribution always keeps the automatic collection enabled.
// tools/build-creator.mjs creates a separate, explicitly named owner build.
export const CREATOR_BUILD = false;
export const RELEASE_VERSION = "1.17.0";
// Le Studio publie sur GitHub : inutile d’interroger plus souvent.
export const POLL_INTERVAL_MS = 180_000;
