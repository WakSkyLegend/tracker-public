// Fenêtre de l'extension : la vue locale, alimentée par le site public du Studio (GitHub Pages).
// L'ancienne vue hébergée sur l'ancien site n'existe plus : plus rien n'est chargé à distance.
import {RELEASE_VERSION} from './build.js';
const frame=document.getElementById('tracker-view'),state=document.getElementById('view-state');
document.getElementById('code-version').textContent='Extension v'+RELEASE_VERSION;
state.textContent='Informations publiées par le Studio de WakSkyLegend';
frame.src=chrome.runtime.getURL('popup.html');
